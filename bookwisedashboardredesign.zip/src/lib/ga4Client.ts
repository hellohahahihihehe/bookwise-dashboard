import { google } from "googleapis";

export function isGa4Configured(): boolean {
  return Boolean(process.env.GA4_PROPERTY_ID && process.env.GOOGLE_SERVICE_ACCOUNT_KEY);
}

function getAuth() {
  const key = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY as string);
  return new google.auth.GoogleAuth({
    credentials: { client_email: key.client_email, private_key: key.private_key },
    scopes: ["https://www.googleapis.com/auth/analytics.readonly"],
  });
}

export interface Ga4WeeklyRow {
  weekStart: string;
  eventName: string;
  count: number;
}

/**
 * Pulls weekly event counts from GA4 for the given event names, from
 * DATASET_START to today. Requires GA4_PROPERTY_ID and
 * GOOGLE_SERVICE_ACCOUNT_KEY (service account JSON, granted "Viewer" on the
 * GA4 property) to be set as environment variables — see README for setup.
 */
export async function fetchGa4WeeklyEventCounts(
  eventNames: string[],
  startDate: string
): Promise<Ga4WeeklyRow[]> {
  const propertyId = process.env.GA4_PROPERTY_ID;
  if (!propertyId) throw new Error("GA4_PROPERTY_ID not set");

  const authClient = await getAuth().getClient();
  const analyticsData = google.analyticsdata({ version: "v1beta", auth: authClient as never });

  const res = await analyticsData.properties.runReport({
    property: `properties/${propertyId}`,
    requestBody: {
      dateRanges: [{ startDate, endDate: "today" }],
      dimensions: [{ name: "isoYearIsoWeek" }, { name: "eventName" }],
      metrics: [{ name: "eventCount" }],
      dimensionFilter: {
        filter: {
          fieldName: "eventName",
          inListFilter: { values: eventNames },
        },
      },
      limit: "10000",
    },
  });

  const rows = res.data.rows ?? [];
  return rows.map((row) => ({
    weekStart: String(row.dimensionValues?.[0]?.value ?? ""),
    eventName: String(row.dimensionValues?.[1]?.value ?? ""),
    count: Number(row.metricValues?.[0]?.value ?? 0),
  }));
}
