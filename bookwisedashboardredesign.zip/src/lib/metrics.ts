import { Channel, WeeklyDataset } from "./types";
import { pctChange } from "./format";

export function weekLabel(iso: string): string {
  const d = new Date(iso + "T00:00:00Z");
  return `${String(d.getUTCDate()).padStart(2, "0")}/${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}

export function lastN<T>(arr: T[], n: number): T[] {
  return arr.slice(-n);
}

export function latestValue(arr: (number | null)[]): number | null {
  for (let i = arr.length - 1; i >= 0; i--) {
    if (arr[i] !== null) return arr[i];
  }
  return null;
}

export function wowChange(arr: number[]): number | null {
  if (arr.length < 2) return null;
  return pctChange(arr[arr.length - 1], arr[arr.length - 2]);
}

export function momChange(arr: number[]): number | null {
  if (arr.length < 8) return null;
  const last4 = arr.slice(-4);
  const prev4 = arr.slice(-8, -4);
  const avg = (xs: number[]) => xs.reduce((s, v) => s + v, 0) / xs.length;
  return pctChange(avg(last4), avg(prev4));
}

export function trailingSum(arr: number[], n: number): number {
  return arr.slice(-n).reduce((s, v) => s + v, 0);
}

export interface DashboardSeries {
  weeks: string[];
  labels: string[];
  mau: number[];
  dau: number[];
  nsmSummariesPerUser: number[];
  d1: (number | null)[];
  d7: (number | null)[];
  d30: (number | null)[];
  activationRate: number[];
  organicSharePct: number[];
  cacTrailing8wk: (number | null)[];
  roasTrailing8wk: (number | null)[];
  revenue: number[];
  spend: number[];
  installs: number[];
}

export function buildDashboardSeries(data: WeeklyDataset): DashboardSeries {
  const weeks = data.weeks;
  const labels = weeks.map(weekLabel);
  const mau = data.engagement.map((e) => e.mau);
  const dau = data.engagement.map((e) => e.dau);
  const nsmSummariesPerUser = data.engagement.map((e) => e.summariesPerActiveUserWeek);
  const d1 = data.retention.map((r) => r.d1);
  const d7 = data.retention.map((r) => r.d7);
  const d30 = data.retention.map((r) => r.d30);
  const activationRate = data.funnel.map((f) => (f.installs > 0 ? (f.activated / f.installs) * 100 : 0));
  const organicSharePct = data.acquisition.map((a) => (a.installs > 0 ? (a.organicInstalls / a.installs) * 100 : 100));
  const spend = data.acquisition.map((a) => a.spend);
  const installs = data.acquisition.map((a) => a.installs);
  const revenue = data.revenue.map((r) => r.revenue);
  const paidNew = data.funnel.map((f) => f.paidNew);

  const cacTrailing8wk = weeks.map((_, i) => {
    const spendSum = trailingSum(spend.slice(0, i + 1), 8);
    const paidSum = trailingSum(paidNew.slice(0, i + 1), 8);
    return paidSum > 0 ? spendSum / paidSum : null;
  });

  const roasTrailing8wk = data.revenue.map((r) => r.roas);

  return {
    weeks,
    labels,
    mau,
    dau,
    nsmSummariesPerUser,
    d1,
    d7,
    d30,
    activationRate,
    organicSharePct,
    cacTrailing8wk,
    roasTrailing8wk,
    revenue,
    spend,
    installs,
  };
}

export interface ChannelTotals {
  channel: Channel;
  spend: number;
  installs: number;
  trialStarts: number;
  paidNew: number;
  revenue: number;
  cac: number | null;
  roas: number | null;
}

export function aggregateChannelTotals(data: WeeklyDataset): ChannelTotals[] {
  const byChannel = new Map<Channel, ChannelTotals>();
  data.channels.forEach((c) => {
    const existing = byChannel.get(c.channel) ?? {
      channel: c.channel,
      spend: 0,
      installs: 0,
      trialStarts: 0,
      paidNew: 0,
      revenue: 0,
      cac: null,
      roas: null,
    };
    existing.spend += c.spend;
    existing.installs += c.installs;
    existing.trialStarts += c.trialStarts;
    existing.paidNew += c.paidNew;
    existing.revenue += c.revenue;
    byChannel.set(c.channel, existing);
  });
  return Array.from(byChannel.values())
    .map((c) => ({
      ...c,
      cac: c.paidNew > 0 ? c.spend / c.paidNew : null,
      roas: c.spend > 0 ? c.revenue / c.spend : null,
    }))
    .sort((a, b) => b.spend - a.spend);
}

export interface RoundSummary {
  round: number;
  label: string;
  start: string;
  end: string;
  spend: number;
  installs: number;
  cpi: number | null;
  d1: number | null;
  d7: number | null;
  paidNew: number;
  roas: number | null;
  cac: number | null;
}

export function summarizeRounds(data: WeeklyDataset): RoundSummary[] {
  return data.rounds.map((r) => {
    const weeksInRound = data.weeks.filter((w) => w >= r.start && w <= r.end);
    const idxs = weeksInRound.map((w) => data.weeks.indexOf(w));
    const spend = idxs.reduce((s, i) => s + data.acquisition[i].spend, 0);
    const installs = idxs.reduce((s, i) => s + data.acquisition[i].installs, 0);
    const paidNew = idxs.reduce((s, i) => s + data.funnel[i].paidNew, 0);
    const revenue = idxs.reduce((s, i) => s + data.revenue[i].revenue, 0);
    const d1s = idxs.map((i) => data.retention[i].d1).filter((v): v is number => v !== null);
    const d7s = idxs.map((i) => data.retention[i].d7).filter((v): v is number => v !== null);
    const avg = (xs: number[]) => (xs.length ? xs.reduce((s, v) => s + v, 0) / xs.length : null);
    return {
      round: r.round,
      label: r.label,
      start: r.start,
      end: r.end,
      spend,
      installs,
      cpi: installs > 0 ? spend / installs : null,
      d1: avg(d1s),
      d7: avg(d7s),
      paidNew,
      roas: spend > 0 ? revenue / spend : null,
      cac: paidNew > 0 ? spend / paidNew : null,
    };
  });
}
