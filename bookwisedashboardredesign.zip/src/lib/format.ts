import { TargetDirection } from "./types";

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-US").format(Math.round(n));
}

export function formatCompact(n: number): string {
  return new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 1 }).format(n);
}

export function formatCurrency(n: number): string {
  const digits = Math.abs(n) < 20 ? 2 : 0;
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: digits }).format(n);
}

export function formatPercent(n: number, digits = 1): string {
  return `${n.toFixed(digits)}%`;
}

export function formatByUnit(value: number, unit: "%" | "$" | "x" | "count"): string {
  switch (unit) {
    case "%":
      return formatPercent(value);
    case "$":
      return formatCurrency(value);
    case "x":
      return `${value.toFixed(1)}x`;
    default:
      return formatCompact(value);
  }
}

export type Status = "good" | "warning" | "critical" | "neutral";

export function computeStatus(
  value: number | null,
  target: number | null,
  direction: TargetDirection
): Status {
  if (value === null || target === null || target === 0) return "neutral";
  const ratio = direction === "higher_is_better" ? value / target : target / value;
  if (ratio >= 1) return "good";
  if (ratio >= 0.85) return "warning";
  return "critical";
}

export function pctChange(current: number, previous: number): number | null {
  if (previous === 0) return null;
  return ((current - previous) / previous) * 100;
}
