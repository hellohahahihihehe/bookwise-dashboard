import { google } from "googleapis";

export function isSheetsConfigured(): boolean {
  return Boolean(process.env.UA_REPORT_SHEET_ID && process.env.GOOGLE_SERVICE_ACCOUNT_KEY);
}

function getAuth() {
  const key = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY as string);
  return new google.auth.GoogleAuth({
    credentials: { client_email: key.client_email, private_key: key.private_key },
    scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
  });
}

/**
 * Reads a range from the UA report Google Sheet (spend/installs/CAC/ROAS by
 * channel and round). Requires UA_REPORT_SHEET_ID and
 * GOOGLE_SERVICE_ACCOUNT_KEY env vars, and the sheet shared with the service
 * account's client_email as Viewer — see README for setup.
 */
export async function fetchSheetRange(range: string): Promise<string[][]> {
  const spreadsheetId = process.env.UA_REPORT_SHEET_ID;
  if (!spreadsheetId) throw new Error("UA_REPORT_SHEET_ID not set");

  const authClient = await getAuth().getClient();
  const sheets = google.sheets({ version: "v4", auth: authClient as never });

  const res = await sheets.spreadsheets.values.get({ spreadsheetId, range });
  return (res.data.values as string[][]) ?? [];
}
