import { Dataset, WeeklyDataset } from "./types";
import { generateMockDataset } from "./mockData";
import { fetchGa4WeeklyEventCounts, isGa4Configured } from "./ga4Client";
import { fetchSheetRange, isSheetsConfigured } from "./sheetsClient";

// Phase 1 (current): fully mock, algorithmically generated so the shape and
// week range always match what live data will look like.
// Phase 2 (once GA4_PROPERTY_ID / GOOGLE_SERVICE_ACCOUNT_KEY / UA_REPORT_SHEET_ID
// are set — see README "Kết nối dữ liệu thật"): overlays real GA4 install
// counts and real Sheet spend onto the dataset. Funnel/retention/engagement/
// revenue stay mock-derived until their GA4 custom events are also wired in —
// each remaining metric's exact event name is listed in the README.
export async function getDataset(): Promise<Dataset> {
  const base = generateMockDataset();
  const ga4Ready = isGa4Configured();
  const sheetsReady = isSheetsConfigured();

  if (!ga4Ready && !sheetsReady) {
    return mockDataset(base);
  }

  try {
    const merged = await overlayLiveData(base, ga4Ready, sheetsReady);
    return {
      meta: {
        mode: "live",
        ga4Connected: ga4Ready,
        sheetsConnected: sheetsReady,
        generatedAt: new Date().toISOString(),
        asOfWeek: base.weeks[base.weeks.length - 1],
      },
      data: merged,
    };
  } catch (err) {
    console.warn("[dataSource] Live fetch failed, falling back to mock data:", err);
    return mockDataset(base);
  }
}

function mockDataset(data: WeeklyDataset): Dataset {
  return {
    meta: {
      mode: "mock",
      ga4Connected: false,
      sheetsConnected: false,
      generatedAt: new Date().toISOString(),
      asOfWeek: data.weeks[data.weeks.length - 1],
    },
    data,
  };
}

async function overlayLiveData(
  base: WeeklyDataset,
  ga4Ready: boolean,
  sheetsReady: boolean
): Promise<WeeklyDataset> {
  const data: WeeklyDataset = structuredClone(base);
  const startDate = data.weeks[0];

  if (ga4Ready) {
    const rows = await fetchGa4WeeklyEventCounts(["first_open"], startDate);
    const installsByWeek = new Map<string, number>();
    rows.forEach((r) => {
      if (r.eventName !== "first_open") return;
      const iso = isoYearWeekToMonday(r.weekStart);
      installsByWeek.set(iso, (installsByWeek.get(iso) ?? 0) + r.count);
    });
    data.acquisition = data.acquisition.map((w) =>
      installsByWeek.has(w.weekStart) ? { ...w, installs: installsByWeek.get(w.weekStart) as number } : w
    );
  }

  if (sheetsReady) {
    // Expected sheet layout (see README): columns Week | Channel | Spend | Installs
    const rows = await fetchSheetRange("UA Report!A2:D");
    const spendByWeekChannel = new Map<string, number>();
    rows.forEach(([week, channel, spend]) => {
      if (!week || !channel) return;
      spendByWeekChannel.set(`${week}__${channel}`, Number(spend) || 0);
    });
    data.channels = data.channels.map((c) => {
      const key = `${c.weekStart}__${c.channel}`;
      return spendByWeekChannel.has(key) ? { ...c, spend: spendByWeekChannel.get(key) as number } : c;
    });
  }

  return data;
}

function isoYearWeekToMonday(isoYearWeek: string): string {
  const year = Number(isoYearWeek.slice(0, 4));
  const week = Number(isoYearWeek.slice(4));
  const jan4 = new Date(Date.UTC(year, 0, 4));
  const jan4Day = jan4.getUTCDay() || 7;
  const week1Monday = new Date(jan4);
  week1Monday.setUTCDate(jan4.getUTCDate() - jan4Day + 1);
  const target = new Date(week1Monday);
  target.setUTCDate(week1Monday.getUTCDate() + (week - 1) * 7);
  return target.toISOString().slice(0, 10);
}
