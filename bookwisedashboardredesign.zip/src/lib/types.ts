export type Channel = "Meta" | "TikTok" | "Google UAC";

export interface AcquisitionWeek {
  weekStart: string;
  impressions: number;
  clicks: number;
  installs: number;
  spend: number;
  organicInstalls: number;
}

export interface FunnelWeek {
  weekStart: string;
  installs: number;
  onboardingComplete: number;
  activated: number;
  trialStarts: number;
  paidNew: number;
}

export interface RetentionPoint {
  weekStart: string;
  d1: number | null;
  d7: number | null;
  d30: number | null;
}

export interface EngagementWeek {
  weekStart: string;
  mau: number;
  dau: number;
  summariesPerActiveUserWeek: number;
  sessionMinutes: number;
}

export interface RevenueWeek {
  weekStart: string;
  revenue: number;
  activeSubscribers: number;
  spend: number;
  roas: number | null;
}

export interface ChannelWeek {
  weekStart: string;
  channel: Channel;
  spend: number;
  installs: number;
  trialStarts: number;
  paidNew: number;
  revenue: number;
}

export interface UARound {
  round: number;
  label: string;
  start: string;
  end: string;
}

export interface FunnelStage {
  stage: string;
  value: number;
  pctOfPrevious: number | null;
  pctOfFirst: number;
  benchmarkPct: number | null;
}

export interface WeeklyDataset {
  weeks: string[];
  acquisition: AcquisitionWeek[];
  funnel: FunnelWeek[];
  retention: RetentionPoint[];
  engagement: EngagementWeek[];
  revenue: RevenueWeek[];
  channels: ChannelWeek[];
  rounds: UARound[];
  funnelSnapshot: FunnelStage[];
}

export type DataSourceMode = "mock" | "live";

export interface DatasetMeta {
  mode: DataSourceMode;
  ga4Connected: boolean;
  sheetsConnected: boolean;
  generatedAt: string;
  asOfWeek: string;
}

export interface Dataset {
  meta: DatasetMeta;
  data: WeeklyDataset;
}

export type TargetDirection = "higher_is_better" | "lower_is_better";

export interface TargetDefinition {
  key: string;
  label: string;
  unit: "%" | "$" | "x" | "count";
  defaultValue: number | null;
  direction: TargetDirection;
  cadence: string;
  source: string;
  note?: string;
}
