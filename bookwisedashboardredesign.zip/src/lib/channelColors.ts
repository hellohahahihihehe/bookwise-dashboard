import { Channel } from "./types";

export const CHANNEL_COLOR: Record<Channel, string> = {
  Meta: "var(--series-1)",
  TikTok: "var(--series-2)",
  "Google UAC": "var(--series-3)",
};
