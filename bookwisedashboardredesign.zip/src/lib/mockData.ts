import {
  AcquisitionWeek,
  Channel,
  ChannelWeek,
  EngagementWeek,
  FunnelStage,
  FunnelWeek,
  RetentionPoint,
  RevenueWeek,
  UARound,
  WeeklyDataset,
} from "./types";
import { mulberry32 } from "./rng";

const DATASET_START = "2025-07-07";
const PRICE_PER_MONTH = 9.99;
const WEEKS_PER_MONTH = 4.345;

interface RoundConfig {
  round: number;
  label: string;
  start: string;
  end: string;
  channelWeights: Partial<Record<Channel, number>>;
  weeklySpend: number;
  cpi: number;
  onboardingCVR: number;
  activationRate: number;
  trialRate: number;
  trialToPaid: number;
  d1: number;
  d7OfD1: number;
  d30OfD7: number;
}

const ROUNDS: RoundConfig[] = [
  { round: 1, label: "R1 · Concept test", start: "2025-07-07", end: "2025-07-20", channelWeights: { Meta: 0.7, TikTok: 0.3 }, weeklySpend: 450, cpi: 5.0, onboardingCVR: 0.55, activationRate: 0.35, trialRate: 0.22, trialToPaid: 0.15, d1: 0.08, d7OfD1: 0.35, d30OfD7: 0.25 },
  { round: 2, label: "R2 · Hook iteration", start: "2025-08-04", end: "2025-08-17", channelWeights: { Meta: 0.6, TikTok: 0.4 }, weeklySpend: 600, cpi: 4.2, onboardingCVR: 0.58, activationRate: 0.4, trialRate: 0.25, trialToPaid: 0.16, d1: 0.1, d7OfD1: 0.38, d30OfD7: 0.27 },
  { round: 3, label: "R3 · Onboarding v2", start: "2025-09-15", end: "2025-09-28", channelWeights: { Meta: 0.55, TikTok: 0.45 }, weeklySpend: 750, cpi: 3.6, onboardingCVR: 0.62, activationRate: 0.46, trialRate: 0.28, trialToPaid: 0.18, d1: 0.12, d7OfD1: 0.4, d30OfD7: 0.28 },
  { round: 4, label: "R4 · Audience expansion", start: "2025-11-03", end: "2025-11-16", channelWeights: { Meta: 0.5, TikTok: 0.4, "Google UAC": 0.1 }, weeklySpend: 950, cpi: 3.2, onboardingCVR: 0.64, activationRate: 0.5, trialRate: 0.31, trialToPaid: 0.2, d1: 0.14, d7OfD1: 0.42, d30OfD7: 0.3 },
  { round: 5, label: "R5 · Creative refresh", start: "2025-12-15", end: "2025-12-28", channelWeights: { Meta: 0.45, TikTok: 0.4, "Google UAC": 0.15 }, weeklySpend: 1100, cpi: 2.9, onboardingCVR: 0.66, activationRate: 0.54, trialRate: 0.34, trialToPaid: 0.22, d1: 0.16, d7OfD1: 0.44, d30OfD7: 0.31 },
  { round: 6, label: "R6 · Paywall test", start: "2026-02-09", end: "2026-02-22", channelWeights: { Meta: 0.4, TikTok: 0.35, "Google UAC": 0.25 }, weeklySpend: 1300, cpi: 2.55, onboardingCVR: 0.68, activationRate: 0.58, trialRate: 0.37, trialToPaid: 0.24, d1: 0.18, d7OfD1: 0.46, d30OfD7: 0.32 },
  { round: 7, label: "R7 · Scale readiness test", start: "2026-04-06", end: "2026-04-19", channelWeights: { Meta: 0.4, TikTok: 0.3, "Google UAC": 0.3 }, weeklySpend: 1500, cpi: 2.3, onboardingCVR: 0.7, activationRate: 0.61, trialRate: 0.39, trialToPaid: 0.25, d1: 0.19, d7OfD1: 0.47, d30OfD7: 0.33 },
  { round: 8, label: "R8 · Broad scale pilot", start: "2026-06-08", end: "2026-06-21", channelWeights: { Meta: 0.35, TikTok: 0.3, "Google UAC": 0.35 }, weeklySpend: 1900, cpi: 2.15, onboardingCVR: 0.71, activationRate: 0.63, trialRate: 0.41, trialToPaid: 0.26, d1: 0.21, d7OfD1: 0.48, d30OfD7: 0.34 },
];

function toISODate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function mondayOf(d: Date): Date {
  const date = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = date.getUTCDay();
  const diff = day === 0 ? -6 : 1 - day;
  date.setUTCDate(date.getUTCDate() + diff);
  return date;
}

function addDays(d: Date, n: number): Date {
  const date = new Date(d);
  date.setUTCDate(date.getUTCDate() + n);
  return date;
}

function generateWeeks(startISO: string, endISO: string): string[] {
  const weeks: string[] = [];
  let cursor = mondayOf(new Date(startISO + "T00:00:00Z"));
  const end = mondayOf(new Date(endISO + "T00:00:00Z"));
  while (cursor <= end) {
    weeks.push(toISODate(cursor));
    cursor = addDays(cursor, 7);
  }
  return weeks;
}

function activeRoundFor(weekStart: string): RoundConfig | null {
  return (
    ROUNDS.find((r) => weekStart >= r.start && weekStart <= r.end) ?? null
  );
}

function mostRecentRoundBefore(weekStart: string): RoundConfig {
  const past = ROUNDS.filter((r) => r.end < weekStart);
  return past.length ? past[past.length - 1] : ROUNDS[0];
}

function weekIndexFraction(weekStart: string, weeks: string[]): number {
  const idx = weeks.indexOf(weekStart);
  return weeks.length <= 1 ? 0 : idx / (weeks.length - 1);
}

export function generateMockDataset(): WeeklyDataset {
  const now = new Date();
  const asOf = toISODate(mondayOf(now));
  const weeks = generateWeeks(DATASET_START, asOf);

  const acquisition: AcquisitionWeek[] = [];
  const funnel: FunnelWeek[] = [];
  const retention: RetentionPoint[] = [];
  const engagement: EngagementWeek[] = [];
  const revenue: RevenueWeek[] = [];
  const channels: ChannelWeek[] = [];

  let activeUserPool = 0;
  let activeSubPool = 0;
  const weeklyRevenueSpend: { revenue: number; spend: number }[] = [];

  weeks.forEach((weekStart, idx) => {
    const rand = mulberry32(idx * 97 + 13);
    const round = activeRoundFor(weekStart);
    const baseline = mostRecentRoundBefore(weekStart);
    const frac = weekIndexFraction(weekStart, weeks);

    const organicInstalls = Math.round((10 + frac * 22) * (0.85 + rand() * 0.3));

    let spend = 0;
    let paidInstalls = 0;
    let cfg: RoundConfig;

    if (round) {
      cfg = round;
      spend = round.weeklySpend * (0.9 + rand() * 0.2);
      paidInstalls = Math.round(spend / round.cpi);
    } else {
      cfg = { ...baseline, activationRate: baseline.activationRate * 0.85, trialRate: baseline.trialRate * 0.85 };
    }

    const installs = organicInstalls + paidInstalls;
    const impressions = Math.round((paidInstalls > 0 ? paidInstalls / (round?.cpi ?? 3) : 0) * 450 * (0.9 + rand() * 0.2)) + Math.round(organicInstalls * 8);
    const clicks = Math.round(paidInstalls * (3.2 + rand()) + organicInstalls * 0.6);

    acquisition.push({ weekStart, impressions, clicks, installs, spend: Math.round(spend), organicInstalls });

    const onboardingComplete = Math.round(installs * cfg.onboardingCVR * (0.95 + rand() * 0.1));
    const activated = Math.round(onboardingComplete * (cfg.activationRate / cfg.onboardingCVR) * (0.95 + rand() * 0.1));
    const trialStarts = Math.round(installs * cfg.trialRate * (0.95 + rand() * 0.1));
    const paidNew = Math.round(trialStarts * cfg.trialToPaid * (0.95 + rand() * 0.1));

    funnel.push({ weekStart, installs, onboardingComplete, activated, trialStarts, paidNew });

    const d1 = cfg.d1 * (0.92 + rand() * 0.16);
    const d7 = d1 * cfg.d7OfD1 * (0.95 + rand() * 0.1);
    const cohortAge = (now.getTime() - new Date(weekStart + "T00:00:00Z").getTime()) / (1000 * 60 * 60 * 24);
    const d30 = cohortAge >= 30 ? d7 * cfg.d30OfD7 * (0.95 + rand() * 0.1) : null;

    retention.push({
      weekStart,
      d1: Number((d1 * 100).toFixed(1)),
      d7: Number((d7 * 100).toFixed(1)),
      d30: d30 === null ? null : Number((d30 * 100).toFixed(1)),
    });

    const weeklyRetentionFactor = 0.8 + frac * 0.1 + (rand() * 0.02 - 0.01);
    activeUserPool = activeUserPool * weeklyRetentionFactor + activated;
    const dauMauRatio = 0.14 + frac * 0.1;
    const mau = Math.round(activeUserPool);
    const dau = Math.round(mau * dauMauRatio);
    const summariesPerActiveUserWeek = Number((0.7 + frac * 1.5 + rand() * 0.15).toFixed(2));
    const sessionMinutes = Number((3.5 + frac * 5.5 + rand() * 0.6).toFixed(1));

    engagement.push({ weekStart, mau, dau, summariesPerActiveUserWeek, sessionMinutes });

    const subRetentionFactor = 0.8 + frac * 0.13;
    activeSubPool = activeSubPool * subRetentionFactor + paidNew;
    const weeklyRevenue = Number((activeSubPool * (PRICE_PER_MONTH / WEEKS_PER_MONTH)).toFixed(2));

    weeklyRevenueSpend.push({ revenue: weeklyRevenue, spend });
    const trailing = weeklyRevenueSpend.slice(-8);
    const trailingRevenue = trailing.reduce((s, w) => s + w.revenue, 0);
    const trailingSpend = trailing.reduce((s, w) => s + w.spend, 0);
    const roas = trailingSpend > 0 ? Number((trailingRevenue / trailingSpend).toFixed(2)) : null;

    revenue.push({ weekStart, revenue: weeklyRevenue, activeSubscribers: Math.round(activeSubPool), spend: Math.round(spend), roas });

    if (round) {
      (Object.entries(round.channelWeights) as [Channel, number][]).forEach(([channel, weight]) => {
        const chSpend = spend * weight;
        const chInstalls = Math.round(paidInstalls * weight);
        const chTrials = Math.round(chInstalls * cfg.trialRate);
        const chPaid = Math.round(chTrials * cfg.trialToPaid);
        const chRevenue = Number((chPaid * PRICE_PER_MONTH).toFixed(2));
        channels.push({ weekStart, channel, spend: Math.round(chSpend), installs: chInstalls, trialStarts: chTrials, paidNew: chPaid, revenue: chRevenue });
      });
    }
  });

  const rounds: UARound[] = ROUNDS.map((r) => ({ round: r.round, label: r.label, start: r.start, end: r.end }));

  const funnelSnapshot = buildFunnelSnapshot(acquisition, funnel, retention);

  return { weeks, acquisition, funnel, retention, engagement, revenue, channels, rounds, funnelSnapshot };
}

function buildFunnelSnapshot(
  acquisition: AcquisitionWeek[],
  funnel: FunnelWeek[],
  retention: RetentionPoint[]
): FunnelStage[] {
  const windowSize = 4;
  const recentAcq = acquisition.slice(-windowSize);
  const recentFunnel = funnel.slice(-windowSize);
  const d30Cohorts = retention.filter((r) => r.d30 !== null).slice(-windowSize);

  const impressions = recentAcq.reduce((s, w) => s + w.impressions, 0);
  const clicks = recentAcq.reduce((s, w) => s + w.clicks, 0);
  const installs = recentFunnel.reduce((s, w) => s + w.installs, 0);
  const onboarding = recentFunnel.reduce((s, w) => s + w.onboardingComplete, 0);
  const activated = recentFunnel.reduce((s, w) => s + w.activated, 0);
  const trials = recentFunnel.reduce((s, w) => s + w.trialStarts, 0);
  const paid = recentFunnel.reduce((s, w) => s + w.paidNew, 0);
  const avgD30 = d30Cohorts.length
    ? d30Cohorts.reduce((s, r) => s + (r.d30 ?? 0), 0) / d30Cohorts.length / 100
    : null;
  const retainedD30 = avgD30 !== null ? Math.round(paid * avgD30) : null;

  const stages: { stage: string; value: number; benchmarkPct: number | null }[] = [
    { stage: "Impressions", value: impressions, benchmarkPct: null },
    { stage: "Clicks", value: clicks, benchmarkPct: 1.0 },
    { stage: "Installs", value: installs, benchmarkPct: 20 },
    { stage: "Onboarding complete", value: onboarding, benchmarkPct: 60 },
    { stage: "Activated (1st summary)", value: activated, benchmarkPct: 50 },
    { stage: "Trial started", value: trials, benchmarkPct: 40 },
    { stage: "Paid subscriber", value: paid, benchmarkPct: 25 },
  ];
  if (retainedD30 !== null) {
    stages.push({ stage: "D30 retained (paid)", value: retainedD30, benchmarkPct: 70 });
  }

  const first = stages[0].value || 1;
  return stages.map((s, i) => ({
    stage: s.stage,
    value: s.value,
    pctOfFirst: Number(((s.value / first) * 100).toFixed(2)),
    pctOfPrevious: i === 0 ? null : Number(((s.value / (stages[i - 1].value || 1)) * 100).toFixed(1)),
    benchmarkPct: s.benchmarkPct,
  }));
}
