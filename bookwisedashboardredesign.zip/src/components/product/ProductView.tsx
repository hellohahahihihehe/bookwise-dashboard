"use client";

import { Dataset } from "@/lib/types";
import { useTargets } from "@/components/TargetsProvider";
import { aggregateChannelTotals, buildDashboardSeries, lastN, summarizeRounds } from "@/lib/metrics";
import { computeStatus, formatCurrency, formatPercent } from "@/lib/format";
import { CHANNEL_COLOR } from "@/lib/channelColors";
import FunnelChart from "@/components/ui/FunnelChart";
import LineChart from "@/components/ui/LineChart";
import BarChart from "@/components/ui/BarChart";
import StatusPill from "@/components/ui/StatusPill";
import DataSourceBadge from "@/components/ui/DataSourceBadge";

export default function ProductView({ dataset }: { dataset: Dataset }) {
  const { targets } = useTargets();
  const { data, meta } = dataset;
  const s = buildDashboardSeries(data);
  const window16 = 16;
  const labels16 = lastN(s.labels, window16);

  const channelTotals = aggregateChannelTotals(data);
  const rounds = summarizeRounds(data);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Product / UA Drill-down</h1>
          <p className="secondary text-sm mt-1 max-w-2xl">
            Quyết định cần đưa ra: kênh nào đáng tăng ngân sách, bước phễu nào cần fix trước, round UA nào đáng lặp lại.
          </p>
        </div>
        <DataSourceBadge meta={meta} />
      </div>

      <section className="card p-4">
        <h2 className="text-sm font-semibold secondary mb-3">Funnel Health — 4 tuần gần nhất, so với benchmark ngành</h2>
        <FunnelChart stages={data.funnelSnapshot} />
      </section>

      <section className="grid lg:grid-cols-2 gap-4">
        <div className="card p-4">
          <h2 className="text-sm font-semibold secondary mb-3">Retention theo cohort tuần (D1 / D7 / D30)</h2>
          <LineChart
            categories={labels16}
            series={[
              { name: "D1", color: "var(--series-1)", data: lastN(s.d1, window16), formatter: (v) => formatPercent(v) },
              { name: "D7", color: "var(--series-3)", data: lastN(s.d7, window16), formatter: (v) => formatPercent(v) },
              { name: "D30", color: "var(--series-7)", data: lastN(s.d30, window16), formatter: (v) => formatPercent(v) },
            ]}
            yFormatter={(v) => `${v.toFixed(0)}%`}
            benchmark={{ value: targets.d7_retention ?? 20, label: `Mục tiêu D7 ${targets.d7_retention ?? 20}%` }}
          />
        </div>

        <div className="card p-4">
          <h2 className="text-sm font-semibold secondary mb-3">MAU &amp; DAU (proxy)</h2>
          <LineChart
            categories={labels16}
            series={[
              { name: "MAU", color: "var(--series-1)", data: lastN(s.mau, window16) },
              { name: "DAU", color: "var(--series-4)", data: lastN(s.dau, window16) },
            ]}
            yFormatter={(v) => v.toFixed(0)}
          />
        </div>

        <div className="card p-4">
          <h2 className="text-sm font-semibold secondary mb-3">Engagement depth — Summaries / Active user / Tuần</h2>
          <LineChart
            categories={labels16}
            series={[{ name: "Summaries/user/tuần", color: "var(--series-1)", data: lastN(s.nsmSummariesPerUser, window16) }]}
            yFormatter={(v) => v.toFixed(1)}
          />
        </div>

        <div className="card p-4">
          <h2 className="text-sm font-semibold secondary mb-3">CAC theo round UA</h2>
          <p className="text-xs muted mb-2">
            Spend không liên tục nên CAC theo tuần rất nhiễu — dùng CAC theo round để so sánh hiệu quả thử nghiệm.
          </p>
          <LineChart
            categories={rounds.map((r) => r.label.split(" · ")[0])}
            series={[{ name: "CAC ($)", color: "var(--series-2)", data: rounds.map((r) => r.cac), formatter: (v) => formatCurrency(v) }]}
            yFormatter={(v) => `$${v.toFixed(0)}`}
            benchmark={targets.cac_paid !== null ? { value: targets.cac_paid, label: `Mục tiêu CAC $${targets.cac_paid}` } : undefined}
          />
        </div>
      </section>

      <section className="card p-4">
        <h2 className="text-sm font-semibold secondary mb-3">Hiệu suất theo kênh — cộng dồn từ 07/2025</h2>
        <div className="grid lg:grid-cols-2 gap-6 mb-5">
          <div>
            <p className="text-xs secondary mb-2">CAC theo kênh</p>
            <BarChart
              data={channelTotals.map((c) => ({ label: c.channel, value: c.cac ?? 0, color: CHANNEL_COLOR[c.channel] }))}
              valueFormatter={(v) => formatCurrency(v)}
            />
          </div>
          <div>
            <p className="text-xs secondary mb-2">ROAS theo kênh</p>
            <BarChart
              data={channelTotals.map((c) => ({ label: c.channel, value: c.roas ?? 0, color: CHANNEL_COLOR[c.channel] }))}
              valueFormatter={(v) => `${v.toFixed(1)}x`}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left secondary text-xs">
                <th className="py-1.5 pr-3 font-medium">Channel</th>
                <th className="py-1.5 pr-3 font-medium">Spend</th>
                <th className="py-1.5 pr-3 font-medium">Installs</th>
                <th className="py-1.5 pr-3 font-medium">Trials</th>
                <th className="py-1.5 pr-3 font-medium">Paid new</th>
                <th className="py-1.5 pr-3 font-medium">CAC</th>
                <th className="py-1.5 pr-3 font-medium">ROAS</th>
              </tr>
            </thead>
            <tbody>
              {channelTotals.map((c) => (
                <tr key={c.channel} style={{ borderTop: "1px solid var(--gridline)" }}>
                  <td className="py-2 pr-3">
                    <span className="inline-flex items-center gap-1.5">
                      <span style={{ width: 8, height: 8, borderRadius: 999, background: CHANNEL_COLOR[c.channel], display: "inline-block" }} />
                      {c.channel}
                    </span>
                  </td>
                  <td className="py-2 pr-3 tabular">{formatCurrency(c.spend)}</td>
                  <td className="py-2 pr-3 tabular">{c.installs}</td>
                  <td className="py-2 pr-3 tabular">{c.trialStarts}</td>
                  <td className="py-2 pr-3 tabular">{c.paidNew}</td>
                  <td className="py-2 pr-3 tabular">
                    <span className="inline-flex items-center gap-1.5">
                      {c.cac !== null ? formatCurrency(c.cac) : "—"}
                      <StatusPill status={computeStatus(c.cac, targets.cac_paid, "lower_is_better")} label="" />
                    </span>
                  </td>
                  <td className="py-2 pr-3 tabular">
                    <span className="inline-flex items-center gap-1.5">
                      {c.roas !== null ? `${c.roas.toFixed(2)}x` : "—"}
                      <StatusPill status={computeStatus(c.roas, targets.roas, "higher_is_better")} label="" />
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card p-4">
        <h2 className="text-sm font-semibold secondary mb-3">So sánh theo round UA</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left secondary text-xs">
                <th className="py-1.5 pr-3 font-medium">Round</th>
                <th className="py-1.5 pr-3 font-medium">Thời gian</th>
                <th className="py-1.5 pr-3 font-medium">Spend</th>
                <th className="py-1.5 pr-3 font-medium">Installs</th>
                <th className="py-1.5 pr-3 font-medium">CPI</th>
                <th className="py-1.5 pr-3 font-medium">D1</th>
                <th className="py-1.5 pr-3 font-medium">D7</th>
                <th className="py-1.5 pr-3 font-medium">Paid new</th>
                <th className="py-1.5 font-medium">ROAS</th>
              </tr>
            </thead>
            <tbody>
              {rounds.map((r) => (
                <tr key={r.round} style={{ borderTop: "1px solid var(--gridline)" }}>
                  <td className="py-2 pr-3 font-medium">{r.label}</td>
                  <td className="py-2 pr-3 muted text-xs">
                    {r.start} → {r.end}
                  </td>
                  <td className="py-2 pr-3 tabular">{formatCurrency(r.spend)}</td>
                  <td className="py-2 pr-3 tabular">{r.installs}</td>
                  <td className="py-2 pr-3 tabular">{r.cpi !== null ? formatCurrency(r.cpi) : "—"}</td>
                  <td className="py-2 pr-3 tabular">{r.d1 !== null ? formatPercent(r.d1) : "—"}</td>
                  <td className="py-2 pr-3 tabular">{r.d7 !== null ? formatPercent(r.d7) : "—"}</td>
                  <td className="py-2 pr-3 tabular">{r.paidNew}</td>
                  <td className="py-2 tabular">{r.roas !== null ? `${r.roas.toFixed(2)}x` : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
