"use client";

import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { TARGET_DEFINITIONS } from "@/lib/targets";

type TargetsMap = Record<string, number | null>;

interface TargetsContextValue {
  targets: TargetsMap;
  setTarget: (key: string, value: number | null) => void;
  loaded: boolean;
}

const TargetsContext = createContext<TargetsContextValue | null>(null);
const STORAGE_KEY = "bookwise-dashboard-targets";

function defaults(): TargetsMap {
  return Object.fromEntries(TARGET_DEFINITIONS.map((t) => [t.key, t.defaultValue]));
}

export function TargetsProvider({ children }: { children: ReactNode }) {
  const [targets, setTargets] = useState<TargetsMap>(defaults);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time hydration of client-only localStorage, not a sync loop
      if (raw) setTargets((prev) => ({ ...prev, ...JSON.parse(raw) }));
    } catch {
      // ignore malformed/unavailable localStorage
    }
    setLoaded(true);
  }, []);

  const setTarget = (key: string, value: number | null) => {
    setTargets((prev) => {
      const next = { ...prev, [key]: value };
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  return <TargetsContext.Provider value={{ targets, setTarget, loaded }}>{children}</TargetsContext.Provider>;
}

export function useTargets() {
  const ctx = useContext(TargetsContext);
  if (!ctx) throw new Error("useTargets must be used inside TargetsProvider");
  return ctx;
}
