"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/leadership", label: "Leadership Summary" },
  { href: "/product", label: "Product / UA Drill-down" },
  { href: "/settings", label: "Targets" },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <header style={{ borderBottom: "1px solid var(--border)", background: "var(--surface-1)" }}>
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        <span className="font-semibold text-sm whitespace-nowrap">BookWise Growth Dashboard</span>
        <nav className="flex gap-1 overflow-x-auto">
          {LINKS.map((l) => {
            const active = pathname === l.href;
            return (
              <Link
                key={l.href}
                href={l.href}
                className="px-3 py-1.5 rounded-md text-sm font-medium whitespace-nowrap transition-colors"
                style={{
                  background: active ? "var(--surface-2)" : "transparent",
                  color: active ? "var(--text-primary)" : "var(--text-secondary)",
                }}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
