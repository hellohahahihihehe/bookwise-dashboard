"use client";

import Link from "next/link";
import { Dataset } from "@/lib/types";
import { useTargets } from "@/components/TargetsProvider";
import { TARGET_DEFINITIONS } from "@/lib/targets";
import { buildDashboardSeries, lastN, latestValue, momChange, summarizeRounds, wowChange } from "@/lib/metrics";
import { computeStatus, formatByUnit } from "@/lib/format";
import StatTile from "@/components/ui/StatTile";
import StatusPill from "@/components/ui/StatusPill";
import FunnelChart from "@/components/ui/FunnelChart";
import DataSourceBadge from "@/components/ui/DataSourceBadge";

function avgLastN(arr: number[], n: number): number {
  const slice = arr.slice(-n);
  return slice.length ? slice.reduce((s, v) => s + v, 0) / slice.length : 0;
}

export default function LeadershipView({ dataset }: { dataset: Dataset }) {
  const { targets } = useTargets();
  const { data, meta } = dataset;
  const s = buildDashboardSeries(data);
  const last = s.weeks.length - 1;

  const nsmSeries = lastN(s.nsmSummariesPerUser, 12);
  const mauSeries = lastN(s.mau, 12);
  const d7Series = lastN(s.d7.map((v) => v ?? 0), 12);
  const revenueSeries = lastN(s.revenue, 12);

  const rounds = summarizeRounds(data);
  const cacByRound = rounds.map((r) => r.cac).filter((v): v is number => v !== null);
  const roasByRound = rounds.map((r) => r.roas).filter((v): v is number => v !== null);
  const latestCac = cacByRound.length ? cacByRound[cacByRound.length - 1] : null;
  const latestRoundRoas = roasByRound.length ? roasByRound[roasByRound.length - 1] : null;

  const constraintStage = data.funnelSnapshot.reduce<{ stage: string; gap: number } | null>((acc, st) => {
    if (st.benchmarkPct === null || st.pctOfPrevious === null) return acc;
    const gap = st.benchmarkPct - st.pctOfPrevious;
    if (gap > 0 && (!acc || gap > acc.gap)) return { stage: st.stage, gap };
    return acc;
  }, null);

  const organicShareTrailing = avgLastN(s.organicSharePct, 4);
  const activationTrailing = avgLastN(s.activationRate, 4);
  const d7Latest = latestValue(s.d7);

  const valueLoop = [
    { label: "Acquisition", value: `${Math.round(avgLastN(s.installs, 4))}`, sub: "installs/tuần (TB 4 tuần)" },
    { label: "Activation", value: `${activationTrailing.toFixed(0)}%`, sub: "hoàn thành summary đầu tiên" },
    { label: "Retention (D7)", value: d7Latest !== null ? `${d7Latest.toFixed(0)}%` : "—", sub: "quay lại ngày 7" },
    { label: "Referral / Growth loop", value: `${organicShareTrailing.toFixed(0)}%`, sub: "install không từ paid (proxy)" },
    { label: "Revenue (ROAS)", value: latestRoundRoas !== null ? `${latestRoundRoas.toFixed(1)}x` : "—", sub: `round gần nhất (${rounds[rounds.length - 1]?.label ?? "—"})` },
  ];

  const targetRows = TARGET_DEFINITIONS.map((def) => {
    let current: number | null = null;
    switch (def.key) {
      case "mau_growth_mom":
        current = momChange(s.mau);
        break;
      case "d7_retention":
        current = d7Latest;
        break;
      case "cac_paid":
        current = latestCac;
        break;
      case "roas":
        current = latestRoundRoas;
        break;
      case "revenue_growth_mom":
        current = momChange(s.revenue);
        break;
      case "organic_share":
        current = organicShareTrailing;
        break;
      case "activation_rate":
        current = activationTrailing;
        break;
      default:
        current = null;
    }
    const target = targets[def.key] ?? null;
    return { def, current, target, status: computeStatus(current, target, def.direction) };
  });

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Leadership Summary</h1>
          <p className="secondary text-sm mt-1 max-w-2xl">
            Quyết định cần đưa ra mỗi tuần: có nên tăng ngân sách UA, giữ nguyên để tối ưu funnel, hay dừng thử nghiệm kênh —
            dựa trên retention, CAC và ROAS hiện tại so với mục tiêu.
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <DataSourceBadge meta={meta} />
          <span className="text-xs muted">Cập nhật đến tuần {s.labels[last]}</span>
        </div>
      </div>

      <section>
        <h2 className="text-sm font-semibold secondary mb-3">Headline — North Star &amp; KPI chiến lược</h2>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-1">
            <StatTile
              label="North Star: Summaries / Active User / Tuần"
              value={s.nsmSummariesPerUser[last]}
              unit="count"
              deltaPct={wowChange(s.nsmSummariesPerUser)}
              series={nsmSeries}
              hero
              accent="var(--series-1)"
            />
          </div>
          <StatTile
            label="Monthly Active Users (MAU proxy)"
            value={s.mau[last]}
            unit="count"
            deltaPct={momChange(s.mau)}
            deltaLabel="so với tháng trước"
            series={mauSeries}
            target={null}
            accent="var(--series-3)"
          />
          <StatTile
            label="D7 Retention"
            value={d7Latest ?? 0}
            unit="%"
            deltaPct={wowChange(s.d7.map((v) => v ?? 0))}
            series={d7Series}
            target={targets.d7_retention}
            accent="var(--series-1)"
          />
          <StatTile
            label="CAC (paid subscriber, round gần nhất)"
            value={latestCac ?? 0}
            unit="$"
            deltaPct={cacByRound.length > 1 ? wowChange(cacByRound) : null}
            deltaLabel="so với round trước"
            series={cacByRound}
            target={targets.cac_paid}
            direction="lower_is_better"
            accent="var(--series-2)"
          />
          <StatTile
            label="ROAS (round gần nhất)"
            value={latestRoundRoas ?? 0}
            unit="x"
            deltaPct={roasByRound.length > 1 ? wowChange(roasByRound) : null}
            deltaLabel="so với round trước"
            series={roasByRound}
            target={targets.roas}
            accent="var(--series-3)"
          />
          <StatTile
            label="Revenue (tuần)"
            value={s.revenue[last]}
            unit="$"
            deltaPct={momChange(s.revenue)}
            deltaLabel="so với tháng trước"
            series={revenueSeries}
            target={null}
            accent="var(--series-6)"
          />
        </div>
      </section>

      <section className="grid lg:grid-cols-[1.3fr_1fr] gap-4">
        <div className="card p-4">
          <div className="flex items-baseline justify-between mb-3">
            <h2 className="text-sm font-semibold secondary">Funnel — điểm nghẽn hiện tại (4 tuần gần nhất)</h2>
            <Link href="/product" className="text-xs" style={{ color: "var(--series-1)" }}>
              Xem chi tiết funnel &amp; theo kênh →
            </Link>
          </div>
          <FunnelChart stages={data.funnelSnapshot} />
          {constraintStage && (
            <p className="text-xs muted mt-3">
              Bước cần ưu tiên xử lý trước: <strong className="secondary">{constraintStage.stage}</strong> — đang thấp hơn
              benchmark ngành nhiều nhất trong toàn phễu.
            </p>
          )}
        </div>

        <div className="flex flex-col gap-4">
          <div className="card p-4">
            <h2 className="text-sm font-semibold secondary mb-1">Growth Loop</h2>
            <p className="text-xs muted mb-2">Chưa được định nghĩa chính thức trong công ty.</p>
            <p className="text-2xl font-semibold secondary">~{organicShareTrailing.toFixed(0)}% <span className="text-xs font-normal muted">(proxy)</span></p>
            <p className="text-xs secondary mt-1">Organic share of installs — proxy tạm thời, TB 4 tuần</p>
            <p className="text-xs muted mt-2">
              Cần leadership chốt: cơ chế loop nào đang/sẽ dùng (referral, share summary, invite...) và metric k-factor cụ thể
              (xem Value Loop calculator đang consider) trước khi track chính thức.
            </p>
          </div>
          <div className="card p-4">
            <h2 className="text-sm font-semibold secondary mb-1">Market Share</h2>
            <p className="text-xs muted mb-2">Chưa có nguồn dữ liệu tự động (không nằm trong GA4).</p>
            <p className="text-2xl font-semibold muted">—</p>
            <p className="text-xs muted mt-2">
              Cần chọn 1 proxy đo được (vd: share of category downloads trên App Store/Play Store qua Sensor Tower/data.ai)
              rồi nhập thủ công theo quý tại tab Targets.
            </p>
          </div>
        </div>
      </section>

      <section className="card p-4">
        <h2 className="text-sm font-semibold secondary mb-3">Value Loop — AARRR rút gọn</h2>
        <div className="flex flex-wrap items-center gap-2">
          {valueLoop.map((step, i) => (
            <div key={step.label} className="flex items-center gap-2">
              <div className="rounded-lg px-3 py-2 min-w-[120px]" style={{ background: "var(--surface-2)" }}>
                <div className="text-xs secondary">{step.label}</div>
                <div className="text-lg font-semibold tabular">{step.value}</div>
                <div className="text-[11px] muted">{step.sub}</div>
              </div>
              {i < valueLoop.length - 1 && <span className="muted">→</span>}
            </div>
          ))}
          <span className="muted">↩ quay lại Acquisition</span>
        </div>
      </section>

      <section className="card p-4">
        <div className="flex items-baseline justify-between mb-3">
          <h2 className="text-sm font-semibold secondary">Mục tiêu &amp; hiện trạng</h2>
          <Link href="/settings" className="text-xs" style={{ color: "var(--series-1)" }}>
            Sửa mục tiêu →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left secondary text-xs">
                <th className="py-1.5 pr-3 font-medium">Metric</th>
                <th className="py-1.5 pr-3 font-medium">Hiện tại</th>
                <th className="py-1.5 pr-3 font-medium">Mục tiêu</th>
                <th className="py-1.5 pr-3 font-medium">Trạng thái</th>
                <th className="py-1.5 font-medium">Cadence / Nguồn</th>
              </tr>
            </thead>
            <tbody>
              {targetRows.map((row) => (
                <tr key={row.def.key} style={{ borderTop: "1px solid var(--gridline)" }}>
                  <td className="py-2 pr-3">{row.def.label}</td>
                  <td className="py-2 pr-3 tabular font-medium">{row.current !== null ? formatByUnit(row.current, row.def.unit) : "—"}</td>
                  <td className="py-2 pr-3 tabular">{row.target !== null ? formatByUnit(row.target, row.def.unit) : "Chưa đặt"}</td>
                  <td className="py-2 pr-3">
                    <StatusPill status={row.status} />
                  </td>
                  <td className="py-2 muted text-xs">
                    {row.def.cadence} · {row.def.source}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
