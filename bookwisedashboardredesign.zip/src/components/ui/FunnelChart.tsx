import { FunnelStage } from "@/lib/types";
import { formatCompact } from "@/lib/format";

function barStatus(stage: FunnelStage): "good" | "critical" | "neutral" {
  if (stage.benchmarkPct === null || stage.pctOfPrevious === null) return "neutral";
  return stage.pctOfPrevious >= stage.benchmarkPct ? "good" : "critical";
}

export default function FunnelChart({ stages }: { stages: FunnelStage[] }) {
  const worst = stages.reduce<{ idx: number; gap: number } | null>((acc, s, i) => {
    if (s.benchmarkPct === null || s.pctOfPrevious === null) return acc;
    const gap = s.benchmarkPct - s.pctOfPrevious;
    if (gap > 0 && (!acc || gap > acc.gap)) return { idx: i, gap };
    return acc;
  }, null);

  return (
    <div className="flex flex-col gap-2.5">
      {stages.map((s, i) => {
        const widthPct = Math.max(s.pctOfFirst, 3);
        const status = barStatus(s);
        const color = status === "good" ? "var(--status-good)" : status === "critical" ? "var(--status-critical)" : "var(--series-1)";
        const isConstraint = worst?.idx === i;
        return (
          <div key={s.stage}>
            <div className="flex items-baseline justify-between text-xs mb-1">
              <span className="secondary font-medium">
                {s.stage}
                {isConstraint && (
                  <span className="ml-2 status-pill critical" style={{ fontSize: 10 }}>
                    Điểm nghẽn lớn nhất
                  </span>
                )}
              </span>
              <span className="tabular">
                <span className="font-semibold">{formatCompact(s.value)}</span>
                {s.pctOfPrevious !== null && (
                  <span className="muted"> · {s.pctOfPrevious.toFixed(1)}% từ bước trước{s.benchmarkPct !== null ? ` (chuẩn ≥${s.benchmarkPct}%)` : ""}</span>
                )}
              </span>
            </div>
            <div className="h-6 rounded-md overflow-hidden" style={{ background: "var(--surface-2)" }}>
              <div className="h-full rounded-md" style={{ width: `${widthPct}%`, background: color, opacity: 0.85 }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}
