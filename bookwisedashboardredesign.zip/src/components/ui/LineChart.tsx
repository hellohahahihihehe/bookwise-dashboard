"use client";

import { useMemo, useRef, useState } from "react";

export interface LineSeries {
  name: string;
  color: string;
  data: (number | null)[];
  formatter?: (v: number) => string;
}

interface LineChartProps {
  categories: string[];
  series: LineSeries[];
  height?: number;
  yFormatter?: (v: number) => string;
  benchmark?: { value: number; label: string };
}

const PAD_LEFT = 44;
const PAD_RIGHT = 16;
const PAD_TOP = 16;
const PAD_BOTTOM = 28;

export default function LineChart({ categories, series, height = 260, yFormatter, benchmark }: LineChartProps) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const width = 640;

  const allValues = series.flatMap((s) => s.data).filter((v): v is number => v !== null);
  const benchValues = benchmark ? [benchmark.value] : [];
  const maxRaw = Math.max(...allValues, ...benchValues, 1);
  const max = niceMax(maxRaw);
  const min = 0;
  const innerW = width - PAD_LEFT - PAD_RIGHT;
  const innerH = height - PAD_TOP - PAD_BOTTOM;
  const n = categories.length;

  const xFor = (i: number) => PAD_LEFT + (n <= 1 ? 0 : (i / (n - 1)) * innerW);
  const yFor = (v: number) => PAD_TOP + (1 - (v - min) / (max - min)) * innerH;

  const paths = useMemo(
    () =>
      series.map((s) => {
        const segments: string[] = [];
        let started = false;
        s.data.forEach((v, i) => {
          if (v === null) {
            started = false;
            return;
          }
          const x = xFor(i);
          const y = yFor(v);
          segments.push(`${started ? "L" : "M"}${x.toFixed(1)},${y.toFixed(1)}`);
          started = true;
        });
        return segments.join(" ");
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [series, width, height, n]
  );

  const gridLines = useMemo(() => {
    const steps = 4;
    return Array.from({ length: steps + 1 }, (_, i) => {
      const v = min + ((max - min) * i) / steps;
      return { v, y: yFor(v) };
    });
  }, [max, min, height]);

  const tickEvery = Math.max(1, Math.ceil(n / 7));

  function handleMove(e: React.PointerEvent<SVGSVGElement>) {
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const relX = ((e.clientX - rect.left) / rect.width) * width;
    const idx = Math.round(((relX - PAD_LEFT) / innerW) * (n - 1));
    setHoverIdx(Math.min(n - 1, Math.max(0, idx)));
  }

  return (
    <div>
      {series.length > 1 && (
        <div className="flex flex-wrap gap-x-4 gap-y-1 mb-2 text-xs secondary">
          {series.map((s) => (
            <span key={s.name} className="inline-flex items-center gap-1.5">
              <span style={{ width: 12, height: 2, background: s.color, display: "inline-block", borderRadius: 1 }} />
              {s.name}
            </span>
          ))}
        </div>
      )}
      <svg
        ref={svgRef}
        viewBox={`0 0 ${width} ${height}`}
        width="100%"
        height={height}
        onPointerMove={handleMove}
        onPointerLeave={() => setHoverIdx(null)}
        role="img"
        aria-label="Biểu đồ xu hướng theo thời gian"
      >
        {gridLines.map((g, i) => (
          <g key={i}>
            <line x1={PAD_LEFT} x2={width - PAD_RIGHT} y1={g.y} y2={g.y} stroke="var(--gridline)" strokeWidth={1} />
            <text x={PAD_LEFT - 8} y={g.y} textAnchor="end" dominantBaseline="middle" fontSize={11} fill="var(--text-muted)">
              {yFormatter ? yFormatter(g.v) : g.v.toFixed(0)}
            </text>
          </g>
        ))}

        {benchmark && (
          <g>
            <line
              x1={PAD_LEFT}
              x2={width - PAD_RIGHT}
              y1={yFor(benchmark.value)}
              y2={yFor(benchmark.value)}
              stroke="var(--text-muted)"
              strokeWidth={1.5}
              strokeDasharray="4 4"
            />
            <text x={width - PAD_RIGHT} y={yFor(benchmark.value) - 4} textAnchor="end" fontSize={10} fill="var(--text-muted)">
              {benchmark.label}
            </text>
          </g>
        )}

        {categories.map((c, i) =>
          i % tickEvery === 0 ? (
            <text key={i} x={xFor(i)} y={height - 8} textAnchor="middle" fontSize={10} fill="var(--text-muted)">
              {c}
            </text>
          ) : null
        )}

        {paths.map((d, i) => (
          <path key={series[i].name} d={d} fill="none" stroke={series[i].color} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
        ))}

        {series.map((s) => {
          const lastIdx = [...s.data].map((v, i) => (v !== null ? i : -1)).filter((i) => i >= 0).pop();
          if (lastIdx === undefined) return null;
          const v = s.data[lastIdx] as number;
          return (
            <circle key={`${s.name}-end`} cx={xFor(lastIdx)} cy={yFor(v)} r={4} fill={s.color} stroke="var(--surface-1)" strokeWidth={2} />
          );
        })}

        {hoverIdx !== null && (
          <line x1={xFor(hoverIdx)} x2={xFor(hoverIdx)} y1={PAD_TOP} y2={height - PAD_BOTTOM} stroke="var(--baseline)" strokeWidth={1} />
        )}
      </svg>

      {hoverIdx !== null && (
        <div
          className="card px-3 py-2 text-xs shadow-sm"
          style={{ position: "relative", top: -Math.max(0, height - 60), maxWidth: 220, pointerEvents: "none" }}
        >
          <div className="font-medium mb-1">{categories[hoverIdx]}</div>
          {series.map((s) => {
            const v = s.data[hoverIdx];
            return (
              <div key={s.name} className="flex items-center justify-between gap-3">
                <span className="inline-flex items-center gap-1.5 secondary">
                  <span style={{ width: 10, height: 2, background: s.color, display: "inline-block" }} />
                  {s.name}
                </span>
                <span className="font-semibold tabular">{v === null || v === undefined ? "—" : s.formatter ? s.formatter(v) : v}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function niceMax(v: number): number {
  if (v <= 0) return 1;
  const magnitude = Math.pow(10, Math.floor(Math.log10(v)));
  const residual = v / magnitude;
  let niceResidual;
  if (residual <= 1) niceResidual = 1;
  else if (residual <= 2) niceResidual = 2;
  else if (residual <= 5) niceResidual = 5;
  else niceResidual = 10;
  return niceResidual * magnitude;
}
