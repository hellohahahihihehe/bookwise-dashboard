import { DatasetMeta } from "@/lib/types";

export default function DataSourceBadge({ meta }: { meta: DatasetMeta }) {
  const label =
    meta.mode === "live"
      ? `Dữ liệu thật · GA4 ${meta.ga4Connected ? "✓" : "–"} · Sheets ${meta.sheetsConnected ? "✓" : "–"}`
      : "Dữ liệu mẫu (mock) — chưa kết nối GA4/Sheets, xem README để nối dữ liệu thật";
  return (
    <span className={`status-pill ${meta.mode === "live" ? "good" : "neutral"}`} style={{ fontSize: 11 }}>
      {label}
    </span>
  );
}
