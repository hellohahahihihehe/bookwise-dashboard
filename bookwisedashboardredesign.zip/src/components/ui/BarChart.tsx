interface BarDatum {
  label: string;
  value: number;
  color: string;
}

interface BarChartProps {
  data: BarDatum[];
  height?: number;
  valueFormatter?: (v: number) => string;
}

export default function BarChart({ data, height = 160, valueFormatter }: BarChartProps) {
  const max = Math.max(...data.map((d) => d.value), 1);

  return (
    <div className="flex items-end gap-3" style={{ height }}>
      {data.map((d) => {
        const barHeight = Math.max((d.value / max) * (height - 32), 2);
        return (
          <div key={d.label} className="flex flex-col items-center justify-end flex-1 min-w-0 h-full">
            <span className="text-xs font-semibold mb-1 tabular">{valueFormatter ? valueFormatter(d.value) : d.value}</span>
            <div
              style={{
                width: "min(28px, 60%)",
                height: barHeight,
                background: d.color,
                borderRadius: "4px 4px 0 0",
              }}
            />
            <span className="text-xs secondary mt-1.5 text-center truncate w-full">{d.label}</span>
          </div>
        );
      })}
    </div>
  );
}
