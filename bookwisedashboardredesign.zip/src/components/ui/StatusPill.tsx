import { Status } from "@/lib/format";

const CONFIG: Record<Status, { icon: string; label: string }> = {
  good: { icon: "✓", label: "Đạt mục tiêu" },
  warning: { icon: "~", label: "Gần đạt" },
  critical: { icon: "!", label: "Dưới mục tiêu" },
  neutral: { icon: "–", label: "Chưa có mục tiêu" },
};

export default function StatusPill({ status, label }: { status: Status; label?: string }) {
  const cfg = CONFIG[status];
  return (
    <span className={`status-pill ${status}`}>
      <span aria-hidden>{cfg.icon}</span>
      {label ?? cfg.label}
    </span>
  );
}
