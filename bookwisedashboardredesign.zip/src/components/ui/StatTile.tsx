import Sparkline from "./Sparkline";
import StatusPill from "./StatusPill";
import { computeStatus, formatByUnit } from "@/lib/format";
import { TargetDirection } from "@/lib/types";

interface StatTileProps {
  label: string;
  value: number;
  unit: "%" | "$" | "x" | "count";
  deltaPct: number | null;
  deltaLabel?: string;
  series?: number[];
  target?: number | null;
  direction?: TargetDirection;
  hero?: boolean;
  accent?: string;
}

export default function StatTile({
  label,
  value,
  unit,
  deltaPct,
  deltaLabel = "so với tuần trước",
  series,
  target = null,
  direction = "higher_is_better",
  hero = false,
  accent = "var(--series-1)",
}: StatTileProps) {
  const status = computeStatus(value, target, direction);
  const deltaGood = deltaPct === null ? null : direction === "higher_is_better" ? deltaPct >= 0 : deltaPct <= 0;

  return (
    <div className="card p-4 flex flex-col gap-2 min-w-0">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm secondary">{label}</span>
        {target !== null ? <StatusPill status={status} /> : <StatusPill status="neutral" />}
      </div>
      <div className="flex items-end justify-between gap-3">
        <span className={hero ? "text-[40px] font-semibold leading-none" : "text-2xl font-semibold leading-none"}>
          {formatByUnit(value, unit)}
        </span>
        {series && series.length > 1 && <Sparkline values={series} accent={accent} />}
      </div>
      <div className="flex items-center justify-between text-xs muted">
        <span>
          {deltaPct === null ? (
            "—"
          ) : (
            <span style={{ color: deltaGood ? "var(--status-good-text)" : "var(--status-critical)" }}>
              {deltaPct >= 0 ? "▲" : "▼"} {Math.abs(deltaPct).toFixed(1)}%
            </span>
          )}{" "}
          {deltaLabel}
        </span>
        <span>{target !== null ? `Mục tiêu: ${formatByUnit(target, unit)}` : "Mục tiêu: chưa đặt (xem tab Targets)"}</span>
      </div>
    </div>
  );
}
