"use client";

import { useTargets } from "@/components/TargetsProvider";
import { TARGET_DEFINITIONS } from "@/lib/targets";

export default function SettingsPage() {
  const { targets, setTarget, loaded } = useTargets();

  return (
    <div className="flex flex-col gap-4 max-w-3xl">
      <div>
        <h1 className="text-xl font-semibold">Targets</h1>
        <p className="secondary text-sm mt-1">
          Đặt mục tiêu cho từng metric — dashboard sẽ tự tính trạng thái đạt/chưa đạt ở Leadership Summary và Product/UA.
          Một số target công ty chưa chốt (đánh dấu bên dưới); dashboard vẫn hiển thị xu hướng thực tế trong lúc chờ quyết
          định, không tự bịa số.
        </p>
        <p className="text-xs muted mt-2">
          Lưu ý: target hiện lưu trên trình duyệt này (localStorage), chưa đồng bộ giữa nhiều người dùng. Khi nối GA4/Sheets
          thật (xem README), nên chuyển sang lưu chung trên 1 Google Sheet hoặc database nhỏ để cả leadership và product
          team thấy cùng một target.
        </p>
      </div>

      <div className="card divide-y" style={{ borderColor: "var(--border)" }}>
        {TARGET_DEFINITIONS.map((def) => (
          <div key={def.key} className="p-4 flex flex-col sm:flex-row sm:items-center gap-3" style={{ borderColor: "var(--gridline)" }}>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm">{def.label}</div>
              <div className="text-xs muted mt-0.5">
                {def.cadence} · {def.source}
              </div>
              {def.note && <div className="text-xs secondary mt-1">{def.note}</div>}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <input
                type="number"
                inputMode="decimal"
                disabled={!loaded}
                placeholder="Chưa đặt"
                value={targets[def.key] ?? ""}
                onChange={(e) => setTarget(def.key, e.target.value === "" ? null : Number(e.target.value))}
                className="w-28 rounded-md px-2 py-1.5 text-sm text-right"
                style={{ border: "1px solid var(--border)", background: "var(--surface-1)" }}
              />
              <span className="text-sm muted w-6">{def.unit}</span>
              {targets[def.key] !== null && (
                <button
                  onClick={() => setTarget(def.key, null)}
                  className="text-xs muted underline"
                  type="button"
                >
                  Xoá
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
