import { getDataset } from "@/lib/dataSource";
import ProductView from "@/components/product/ProductView";

export const revalidate = 3600;

export default async function ProductPage() {
  const dataset = await getDataset();
  return <ProductView dataset={dataset} />;
}
