import { getDataset } from "@/lib/dataSource";
import LeadershipView from "@/components/leadership/LeadershipView";

export const revalidate = 3600;

export default async function LeadershipPage() {
  const dataset = await getDataset();
  return <LeadershipView dataset={dataset} />;
}
