import type { Metadata } from "next";
import "./globals.css";
import Nav from "@/components/Nav";
import { TargetsProvider } from "@/components/TargetsProvider";

export const metadata: Metadata = {
  title: "BookWise Growth Dashboard",
  description: "Weekly leadership review dashboard for BookWise growth performance",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="vi" className="h-full antialiased">
      <body className="min-h-full flex flex-col">
        <TargetsProvider>
          <Nav />
          <main className="flex-1 mx-auto w-full max-w-[1200px] px-4 sm:px-6 py-6">{children}</main>
        </TargetsProvider>
      </body>
    </html>
  );
}
