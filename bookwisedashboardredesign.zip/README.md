# BookWise Growth Dashboard

Dashboard nội bộ để track performance UA/growth của BookWise (book summary, edtech) và dùng cho buổi review hàng tuần với leadership + product team.

Đây là bản làm lại thay cho dashboard cũ trên Replit (`legacy/BookWise_Growth_Dashboard.html`), sau feedback từ leadership:

- Quá chi tiết, nhìn vào không biết nên làm gì tiếp theo
- Nhiều màu sắc không cần thiết, chưa có ý nghĩa rõ ràng
- Thiếu fundamental của một dashboard chuẩn (không rõ decision nào cần đưa ra)

Cách tiếp cận lần này: **decision-first**. Mỗi số trên dashboard trả lời câu hỏi "nếu số này đổi, mình sẽ làm gì khác?" — số nào không trả lời được câu đó thì không đưa vào.

## Cấu trúc

- **`/leadership` — Leadership Summary.** 1 màn hình, dùng để mở đầu buổi review hàng tuần: North Star metric, KPI chiến lược (MAU, D7 retention, CAC, ROAS, revenue), điểm nghẽn lớn nhất trong funnel, Growth Loop & Market share (đánh dấu rõ phần chưa có data), và bảng mục tiêu vs hiện trạng.
- **`/product` — Product / UA Drill-down.** Chi tiết hơn cho product/UA team: funnel đầy đủ so với benchmark ngành, retention curves, engagement depth, hiệu suất theo kênh (Meta/TikTok/Google UAC), so sánh theo round UA.
- **`/settings` (tab "Targets").** Nơi nhập mục tiêu cho từng metric. Một số target công ty chưa chốt (MAU growth, CAC, revenue growth, market share, growth loop) — dashboard vẫn hiển thị xu hướng thực tế, không tự bịa số target.

North Star metric đang dùng: **Summaries Completed / Active User / Tuần**.

## Chạy local

```bash
npm install
npm run dev
```

Mở `http://localhost:3000` (tự redirect sang `/leadership`).

## Dữ liệu: mock trước, GA4/Sheets thật sau

**Hiện tại (Phase 1):** toàn bộ dữ liệu là mock, được sinh thuật toán trong `src/lib/mockData.ts` — luôn tự chạy từ tuần đầu tháng 7/2025 đến tuần hiện tại (dùng ngày thật của máy chủ), mô phỏng đúng nhịp độ 8 round UA test rời rạc mà BookWise đã chạy (không phải spend liên tục). Việc này để leadership/product duyệt UI và logic tính toán trước khi nối dữ liệu thật.

**Phase 2 — nối GA4 + Sheets thật:** set các biến môi trường bên dưới, dashboard sẽ tự chuyển sang `mode: "live"` (xem badge góc trên mỗi trang).

### 1. Kết nối GA4

1. Trong Google Cloud Console, tạo một **Service Account**, bật **Google Analytics Data API**.
2. Tạo key JSON cho service account đó, tải về.
3. Trong GA4 Admin → Property Access Management, thêm email của service account (dạng `xxx@yyy.iam.gserviceaccount.com`) với quyền **Viewer**.
4. Set biến môi trường:
   - `GA4_PROPERTY_ID` — property ID dạng số (Admin → Property Details).
   - `GOOGLE_SERVICE_ACCOUNT_KEY` — toàn bộ nội dung file JSON key, dán thành 1 dòng (1 biến env, dạng JSON string).

Phase 2 hiện tại mới nối **`first_open`** (installs) từ GA4 vào biểu đồ acquisition. Để nối tiếp các metric còn lại, cần thêm các custom event GA4 sau (đặt tên tuỳ ý, cập nhật lại `src/lib/ga4Client.ts` + `src/lib/dataSource.ts` cho khớp):

| Metric trên dashboard | GA4 event cần thêm | Ghi chú |
|---|---|---|
| Activation (Activated · 1st summary) | `summary_completed` (custom event, param `book_id`) | Trigger khi user đọc xong summary đầu tiên |
| Trial started | `trial_start` hoặc GA4 `in_app_purchase` với param trial | Tuỳ flow trial hiện có |
| Paid subscriber | `purchase` (GA4 ecommerce event) | Dùng cho revenue + ROAS |
| Session depth / engagement | `session_start`, `user_engagement` | GA4 đã tự track mặc định |
| D1/D7/D30 retention | Cohort/Retention report trong GA4 Data API (`cohortSpec`) | Cần request riêng, khác `runReport` cơ bản |

### 2. Kết nối UA report Sheet (spend/CAC/ROAS theo kênh)

GA4 không có data về ad spend — số này lấy từ Google Sheet UA report team đang dùng.

1. Share Google Sheet UA report (hoặc tạo 1 sheet riêng cho dashboard) cho email của service account ở trên, quyền **Viewer**.
2. Tạo/đảm bảo có 1 tab tên `UA Report` với cột: `Week | Channel | Spend | Installs` (`Week` dạng `YYYY-MM-DD` là ngày Thứ 2 đầu tuần, `Channel` khớp với `Meta` / `TikTok` / `Google UAC`).
3. Set biến môi trường `UA_REPORT_SHEET_ID` (lấy từ URL sheet).

Hiện tại chỉ có cột `Spend` được overlay vào dashboard (xem `overlayLiveData` trong `src/lib/dataSource.ts`). Muốn nối thêm cột nào thì mở rộng hàm này.

Nếu chỉ set GA4 hoặc chỉ set Sheets (không set cả hai), dashboard vẫn chạy — phần chưa nối tiếp tục dùng mock, phần đã nối dùng data thật.

## Deploy lên Vercel

1. Push repo này lên GitHub (đã có sẵn).
2. Vào [vercel.com](https://vercel.com) → New Project → import repo `bookwise-dashboard`. Vercel tự nhận diện Next.js, không cần config thêm.
3. Trong Project Settings → Environment Variables, thêm `GA4_PROPERTY_ID`, `GOOGLE_SERVICE_ACCOUNT_KEY`, `UA_REPORT_SHEET_ID` khi đã sẵn sàng nối data thật.
4. Deploy. Dashboard tự re-fetch GA4/Sheets mỗi giờ (`revalidate = 3600` ở mỗi page) — không cần thao tác gì thêm để "auto sync".

## Dùng trong buổi review hàng tuần

1. Mở `/leadership` trước — đọc North Star, 5 KPI chiến lược, và "Bước cần ưu tiên xử lý trước" dưới biểu đồ funnel. Đây là điểm bắt đầu thảo luận: có nên tăng ngân sách UA, giữ nguyên để tối ưu funnel, hay dừng thử nghiệm kênh.
2. Nếu câu hỏi đi sâu vào kênh/creative/round cụ thể → chuyển sang `/product`.
3. Khi leadership chốt được target mới (MAU growth, CAC, revenue...) → vào `/settings` nhập ngay, để tuần sau có đường tham chiếu.

## Giới hạn hiện tại (đã biết, không phải bug)

- **Target lưu theo trình duyệt (localStorage)**, chưa dùng chung giữa nhiều người. Nên chuyển sang 1 Google Sheet hoặc database nhỏ khi nhiều người cùng cần sửa target.
- **Market share**: chưa có nguồn dữ liệu tự động — cần chọn 1 proxy đo được (vd Sensor Tower/data.ai category downloads) rồi nhập tay theo quý.
- **Growth Loop**: chưa được công ty định nghĩa chính thức (cơ chế loop, k-factor). Dashboard tạm dùng "organic share of installs" làm proxy, có ghi chú rõ trên UI.
- **CAC/ROAS tính theo round UA**, không theo tuần — vì spend không liên tục (chỉ chạy từng đợt test), CAC theo tuần sẽ rất nhiễu/gây hiểu lầm.
